function verMas() {
    // Redirige al archivo nuevaPagina.html
    window.location.href = 'nuevaPagina.html';
  }
  